import { useState } from 'react';
import { ArrowLeft, Save } from 'lucide-react';
import { supabase, UserPreference } from '../lib/supabase';

type UserPreferencePortalPageProps = {
  onNavigate: (page: string) => void;
};

export function UserPreferencePortalPage({ onNavigate }: UserPreferencePortalPageProps) {
  const [email, setEmail] = useState('');
  const [userId, setUserId] = useState<string | null>(null);
  const [preferences, setPreferences] = useState<UserPreference | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');

    try {
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('email', email)
        .maybeSingle();

      if (userError) throw userError;

      if (!userData) {
        setMessage('User not found. Please check your email address.');
        setUserId(null);
        setPreferences(null);
        return;
      }

      setUserId(userData.id);

      const { data: prefsData, error: prefsError } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', userData.id)
        .maybeSingle();

      if (prefsError) throw prefsError;

      if (prefsData) {
        setPreferences(prefsData);
      } else {
        setPreferences({
          id: '',
          user_id: userData.id,
          promotional_offers: true,
          order_updates: true,
          newsletters: true,
          email_channel: true,
          sms_channel: false,
          push_channel: false,
          updated_at: new Date().toISOString(),
        });
      }
    } catch (error) {
      console.error('Error looking up user:', error);
      setMessage('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!userId || !preferences) return;

    setSaving(true);
    setMessage('');

    try {
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: userId,
          promotional_offers: preferences.promotional_offers,
          order_updates: preferences.order_updates,
          newsletters: preferences.newsletters,
          email_channel: preferences.email_channel,
          sms_channel: preferences.sms_channel,
          push_channel: preferences.push_channel,
        });

      if (error) throw error;

      setMessage('Preferences saved successfully!');
    } catch (error) {
      console.error('Error saving preferences:', error);
      setMessage('Failed to save preferences. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const PreferenceToggle = ({
    label,
    value,
    onChange,
  }: {
    label: string;
    value: boolean;
    onChange: (value: boolean) => void;
  }) => (
    <div className="flex items-center justify-between py-4 border-b border-gray-200">
      <span className="text-gray-700 font-medium">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
          value ? 'bg-pink-600' : 'bg-gray-300'
        }`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            value ? 'translate-x-6' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-white p-4">
      <div className="max-w-2xl mx-auto py-8">
        <button
          onClick={() => onNavigate('home')}
          className="mb-6 flex items-center space-x-2 text-pink-600 hover:text-pink-700 transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Home</span>
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-pink-600 mb-2">Nykaa</h1>
            <h2 className="text-2xl font-semibold text-gray-800">Notification Preferences</h2>
            <p className="text-gray-600 mt-2">Manage how you want to hear from us</p>
          </div>

          {!preferences ? (
            <form onSubmit={handleLookup} className="space-y-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Enter Your Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                  placeholder="your.email@example.com"
                  required
                />
              </div>

              {message && (
                <div
                  className={`px-4 py-3 rounded-lg text-sm ${
                    message.includes('success')
                      ? 'bg-green-50 text-green-600'
                      : 'bg-red-50 text-red-600'
                  }`}
                >
                  {message}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white font-semibold py-3 rounded-lg transition-all disabled:opacity-50"
              >
                {loading ? 'Looking up...' : 'Continue'}
              </button>
            </form>
          ) : (
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Notification Types</h3>
                <div className="space-y-2">
                  <PreferenceToggle
                    label="Promotional Offers"
                    value={preferences.promotional_offers}
                    onChange={(value) =>
                      setPreferences({ ...preferences, promotional_offers: value })
                    }
                  />
                  <PreferenceToggle
                    label="Order Updates"
                    value={preferences.order_updates}
                    onChange={(value) => setPreferences({ ...preferences, order_updates: value })}
                  />
                  <PreferenceToggle
                    label="Newsletters"
                    value={preferences.newsletters}
                    onChange={(value) => setPreferences({ ...preferences, newsletters: value })}
                  />
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Communication Channels</h3>
                <div className="space-y-2">
                  <PreferenceToggle
                    label="Email"
                    value={preferences.email_channel}
                    onChange={(value) => setPreferences({ ...preferences, email_channel: value })}
                  />
                  <PreferenceToggle
                    label="SMS"
                    value={preferences.sms_channel}
                    onChange={(value) => setPreferences({ ...preferences, sms_channel: value })}
                  />
                  <PreferenceToggle
                    label="Push Notifications"
                    value={preferences.push_channel}
                    onChange={(value) => setPreferences({ ...preferences, push_channel: value })}
                  />
                </div>
              </div>

              {message && (
                <div
                  className={`px-4 py-3 rounded-lg text-sm ${
                    message.includes('success')
                      ? 'bg-green-50 text-green-600'
                      : 'bg-red-50 text-red-600'
                  }`}
                >
                  {message}
                </div>
              )}

              <div className="flex space-x-4">
                <button
                  onClick={() => {
                    setPreferences(null);
                    setUserId(null);
                    setEmail('');
                    setMessage('');
                  }}
                  className="flex-1 px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors font-semibold"
                >
                  Back
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex-1 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white px-6 py-3 rounded-lg flex items-center justify-center space-x-2 transition-all font-semibold disabled:opacity-50"
                >
                  <Save size={20} />
                  <span>{saving ? 'Saving...' : 'Save Preferences'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
